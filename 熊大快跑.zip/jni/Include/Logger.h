#pragma once
#include <jni.h>
#include <android/log.h>

enum LogType {oDEBUG = 3,oERROR = 6,oINFO  = 4,oWARN  = 5};
#define TAG ("R3v - Tool")
#define LOGD(fmt, ...) ((void)__android_log_print(oDEBUG, TAG, "[+] " fmt, ##__VA_ARGS__))
#define LOGE(fmt, ...) ((void)__android_log_print(oERROR, TAG, "[-] " fmt, ##__VA_ARGS__))
#define LOGI(fmt, ...) ((void)__android_log_print(oINFO,  TAG, "[+] " fmt, ##__VA_ARGS__))
#define LOGW(fmt, ...) ((void)__android_log_print(oWARN,  TAG, "[-] " fmt, ##__VA_ARGS__))