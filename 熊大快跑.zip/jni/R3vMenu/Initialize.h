/*
           Author: R3v
    Mail: R3v10086@outlook.com
     Date: 2026-03-13 12:33:21
      Copyright (c) 2026 R3v
    SPDX-License-Identifier: MIT
*/

#include "GameCheat/Api.h"
#include "R3vMain.h"

void AllMenuUpdate() {
    R3vMain();
}