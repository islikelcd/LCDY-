/*
           Author: R3v
    Mail: R3v10086@outlook.com
     Date: 2026-03-13 12:33:21
      Copyright (c) 2026 R3v
    SPDX-License-Identifier: MIT
*/

bool EnsureIl2CppThreadAttached() {
    static bool attached = false;
    if (!attached) {
        attached = Il2cpp::EnsureAttached();
        if (attached) {
            LOGI("Il2Cpp 线程附加成功");
        }
    }
    return attached;
}

template<typename T>
T ReadField(Il2CppObject* obj, const char* fieldName, T defaultValue = T()) {
    if (!obj || !EnsureIl2CppThreadAttached()) return defaultValue;
    try {
        return obj->getField<T>(fieldName);
    } catch (...) {
        LOGE("读取字段失败: %s", fieldName);
        return defaultValue;
    }
}

template<typename T>
bool WriteField(Il2CppObject* obj, const char* fieldName, T value) {
    if (!obj || !EnsureIl2CppThreadAttached()) return false;
    try {
        obj->setField<T>(fieldName, value);
        return true;
    } catch (...) {
        LOGE("设置字段失败: %s", fieldName);
        return false;
    }
}

template<typename T, typename... Args>
T CallMethod(Il2CppObject* obj, const char* methodName, Args... args) {
    if (!obj || !EnsureIl2CppThreadAttached()) return T();
    try {
        return obj->invoke_method<T>(methodName, args...);
    } catch (...) {
        LOGE("调用方法失败: %s", methodName);
        return T();
    }
}

template<typename T, typename... Args>
T CallStaticMethod(Il2CppClass* klass, const char* methodName, Args... args) {
    if (!klass || !EnsureIl2CppThreadAttached()) return T();
    try {
        MethodInfo* method = klass->getMethod(methodName);
        if (!method) {
            return T();
        }
        return method->invoke_static<T>(args...);
    } catch (...) {
        LOGE("调用静态方法失败: %s", methodName);
        return T();
    }
}

template<typename T>
T ClampValue(T value, T min, T max) {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

inline const char* GetObjectClassName(Il2CppObject* obj) {
    if (!obj || !EnsureIl2CppThreadAttached()) return "null";
    auto* objClass = Il2cpp::GetObjectClass(obj);
    return objClass->getName();
}

inline bool IsObjectOfClass(Il2CppObject* obj, const char* className) {
    if (!obj || !EnsureIl2CppThreadAttached()) return false;
    auto* objClass = Il2cpp::GetObjectClass(obj);
    return strcmp(objClass->getName(), className) == 0;
}

enum class ItemID : int {
    None = 0,
    Diamond = 1,
    Coin = 2,
    Shield = 3,
    DoubleCoin = 4,
    Pet_Skill = 11,
    Magnet = 20,
    RideShard = 21,
    PetXiaobai = 30,
    Pet1 = 31,
    Pet2 = 32,
    Pet3 = 33,
    PetMax = 49,
    Suipian1 = 51,
    Suipian2 = 52,
    Suipian3 = 53,
    Suipian4 = 54,
    Suipian5 = 55,
    Suipian6 = 56,
    Suipian7 = 57,
    Suipian8 = 58,
    Suipian9 = 59,
    Suipian10 = 60,
    PetNet = 70,
    Fish1 = 71,
    Fish2 = 72,
    Fish3 = 73,
    Fish4 = 74,
    Fish5 = 75,
    Fish6 = 76,
    Role1 = 100,
    Role2 = 101,
    Role3 = 102,
    Role4 = 103,
    Role5 = 104,
    Skill = 150,
    ToyCard1 = 201,
    ToyCard2 = 202,
    ToyCard3 = 203,
    ToyCard4 = 204,
    Physical = 240,
    Resurrect = 800,
    Lottery = 801,
    Free_Game = 802,
    VIP = 803,
    Level_Star = 804,
    Car = 805,
    Boomb = 806,
    Grass = 807,
    Skin_Start = 900,
    Rider_Start = 930,
    Snow_Board = 960,
    DoubleAttack = 1000,
    HpRecover = 1001,
    YiJiBiSha = 1002,
    PAOZHU = 1003,
    ReelStart = 1020,
    FragmentStart = 1040,
    WeaponStart = 1100,
    GameLevel = 1150,
    Egg = 1160
};

class PlayerManager {
private:
    static Il2CppClass* GetPlayerControlClass() {
        static Il2CppClass* playerControlClass = nullptr;
        if (!playerControlClass) {
            auto& images = Il2cpp::GetImages();
            for (auto image : images) {
                playerControlClass = image->getClass("PlayerControl");
                if (playerControlClass) break;
            }
        }
        return playerControlClass;
    }

public:
    static Il2CppObject* GetPlayerInstance() {
        if (!Il2cpp::EnsureAttached()) return nullptr;
        auto* playerClass = GetPlayerControlClass();
        if (!playerClass) return nullptr;
        
        FieldInfo* selfField = playerClass->getField("self");
        if (!selfField) return nullptr;
        
        Il2CppObject* playerInstance = nullptr;
        Il2cpp::GetFieldStaticValue(selfField, &playerInstance);
        return playerInstance;
    }
    
    static bool IsValidPlayer(Il2CppObject* player) {
        if (!player || !Il2cpp::EnsureAttached()) return false;
        auto* objClass = Il2cpp::GetObjectClass(player);
        auto* expectedClass = GetPlayerControlClass();
        return objClass == expectedClass;
    }
};

class ItemManager {
private:
    static Il2CppObject* instance;
    static bool checked;
    
    static Il2CppClass* GetItemManagerClass() {
        static Il2CppClass* itemManagerClass = nullptr;
        if (!itemManagerClass) {
            auto& images = Il2cpp::GetImages();
            for (auto image : images) {
                itemManagerClass = image->getClass("ItemManager");
                if (itemManagerClass) break;
            }
        }
        return itemManagerClass;
    }
    
public:
    static Il2CppObject* GetInstance() {
        if (!checked) {
            auto* itemManagerClass = GetItemManagerClass();
            if (itemManagerClass) {
                FieldInfo* instanceField = itemManagerClass->getField("instance");
                if (instanceField) {
                    instance = instanceField->getStaticValue<Il2CppObject*>();
                }
            }
            checked = true;
        }
        return instance;
    }
    static void ResetInstance() {
        instance = nullptr;
        checked = false;
    }
    
    static bool AddItem(int itemId, int count) {
        auto* inst = GetInstance();
        if (!inst) return false;
        try {
            CallMethod<void>(inst, "AddItem", itemId, count);
            return true;
        } catch (const std::exception& e) {
            LOGE("AddItem 失败 (int): %s", e.what());
            try {
                CallMethod<void>(inst, "AddItem", (ItemID)itemId, count);
                return true;
            } catch (const std::exception& e2) {
                LOGE("AddItem 失败 (ItemID): %s", e2.what());
                return false;
            }
        }
    }
    
    static bool AddItem(ItemID itemId, int count) {
        return AddItem(static_cast<int>(itemId), count);
    }
    
    static bool UseItem(int itemId, int count) {
        auto* inst = GetInstance();
        if (!inst) return false;
        try {
            bool result = CallMethod<bool>(inst, "UseItem", itemId, count);
            return result;
        } catch (const std::exception& e) {
            LOGE("UseItem 失败: %s", e.what());
            return false;
        }
    }
    
    static bool UseItem(ItemID itemId, int count) {
        return UseItem(static_cast<int>(itemId), count);
    }
    
    static int GetItemCount(int itemId) {
        auto* inst = GetInstance();
        if (!inst) return 0;
        
        try {
            auto* item = CallMethod<Il2CppObject*>(inst, "GetItem", itemId);
            if (item) {
                int count = ReadField<int>(item, "count", 0);
                return count;
            }
        } catch (const std::exception& e) {
            LOGE("GetItemCount 失败: %s", e.what());
        }
        
        return 0;
    }
    
    static int GetItemCount(ItemID itemId) {
        return GetItemCount(static_cast<int>(itemId));
    }
    
    static bool UpgradeItem(int itemId, int level) {
        auto* inst = GetInstance();
        if (!inst) return false;
        try {
            CallMethod<void>(inst, "UpgradeItem", itemId, level);
            return true;
        } catch (const std::exception& e) {
            LOGE("UpgradeItem 失败: %s", e.what());
            return false;
        }
    }
    
    static Il2CppObject* GetItemObject(int itemId) {
        auto* inst = GetInstance();
        if (!inst) return nullptr;
        try {
            return CallMethod<Il2CppObject*>(inst, "GetItem", itemId);
        } catch (const std::exception& e) {
            LOGE("GetItemObject 失败: %s", e.what());
            return nullptr;
        }
    }
};

Il2CppObject* ItemManager::instance = nullptr;
bool ItemManager::checked = false;

class VipManager {
private:
    static Il2CppClass* vipClass;
    static Il2CppObject* vipInstance;
    
    static void InitializeClass() {
        if (!vipClass) {
            auto& images = Il2cpp::GetImages();
            for (auto image : images) {
                vipClass = image->getClass("VipManager");
                if (vipClass) break;
            }
        }
    }
    
public:
    static Il2CppObject* GetInstance() {
        if (!vipInstance) {
            if (!vipClass) InitializeClass();
            if (vipClass) {
                FieldInfo* instanceField = vipClass->getField("instance");
                if (instanceField) {
                    vipInstance = instanceField->getStaticValue<Il2CppObject*>();
                }
            }
        }
        return vipInstance;
    }
    
    static void ApplyBonuses(float coinBonus, float scoreBonus, float propTimeBonus, float boxBonus) {
        auto instance = GetInstance();
        if (!instance) return;
        WriteField<float>(instance, "m_CoinAdd", coinBonus);
        WriteField<float>(instance, "m_ScoreAdd", scoreBonus);
        WriteField<float>(instance, "m_PropTimeAdd", propTimeBonus);
        WriteField<float>(instance, "m_BoxNumAdd", boxBonus);
    }
    
    static void ClaimDailyReward() {
        auto instance = GetInstance();
        if (!instance) return;
        CallMethod<void>(instance, "GetDailyReward");
    }
    
    static Il2CppClass* GetVipClass() {
        if (!vipClass) InitializeClass();
        return vipClass;
    }
    
    static void ResetInstance() {
        vipInstance = nullptr;
    }
};

Il2CppClass* VipManager::vipClass = nullptr;
Il2CppObject* VipManager::vipInstance = nullptr;