#include <jni.h>
#include <cmath>
#include <thread>
#include <unistd.h>
#include <pthread.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <sys/system_properties.h>
#include <android/input.h>
#include <unordered_map>
#include "钩子功能.h"

__attribute__((constructor))
void lib_main() {
    pthread_t ptid;
    pthread_create(&ptid, nullptr, hack_thread, nullptr);
    pthread_detach(ptid);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    return JNI_VERSION_1_6;
}

/*
           Author: R3v
    Mail: R3v10086@outlook.com
     Date: 2026-03-13 12:33:21
      Copyright (c) 2026 R3v
    SPDX-License-Identifier: MIT
*/