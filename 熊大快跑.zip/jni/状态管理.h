#include <android/input.h>
#include <android/native_window.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <unordered_map>

struct EGLContextInfo {
    int glWidth = 0;
    int glHeight = 0;
    int screenWidth = 0;
    int screenHeight = 0;
    bool dpiInitialized = false;
    void* eglHandle = nullptr;
};

struct TouchPoint {
    int id;
    float x, y;
    bool down;
};

static EGLContextInfo g_Egl;
static std::unordered_map<int, TouchPoint> g_TouchPoints;
static int g_TouchCount = 0;
static bool g_Initialized = false;
static bool g_InitDone = false;

static void (*old_input)(void* event, void* exAb, void* exAc);
static void hook_input(void* event, void* exAb, void* exAc) {
    if (old_input) old_input(event, exAb, exAc);
    AInputEvent* inputEvent = (AInputEvent*)event;
    if (AInputEvent_getType(inputEvent) != AINPUT_EVENT_TYPE_MOTION) {
        g_TouchCount = 0;
        g_TouchPoints.clear();
        return;
    }
    int action = AMotionEvent_getAction(inputEvent);
    int actionMasked = action & AMOTION_EVENT_ACTION_MASK;
    int pointerIndex = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    int pointerCount = AMotionEvent_getPointerCount(inputEvent);
    switch (actionMasked) {
        case AMOTION_EVENT_ACTION_DOWN:
        case AMOTION_EVENT_ACTION_POINTER_DOWN: {
            int id = AMotionEvent_getPointerId(inputEvent, pointerIndex);
            float x = AMotionEvent_getX(inputEvent, pointerIndex);
            float y = AMotionEvent_getY(inputEvent, pointerIndex);
            g_TouchPoints[id] = {id, x, y, true};
            g_TouchCount = g_TouchPoints.size();
            if (id == 0) {
                auto& io = ImGui::GetIO();
                io.AddMousePosEvent(x, y);
                io.AddMouseButtonEvent(0, true);
            }
            break;
        }
        
        case AMOTION_EVENT_ACTION_MOVE: {
            for (int i = 0; i < pointerCount; i++) {
                int id = AMotionEvent_getPointerId(inputEvent, i);
                float x = AMotionEvent_getX(inputEvent, i);
                float y = AMotionEvent_getY(inputEvent, i);
                auto& point = g_TouchPoints[id];
                point.x = x;
                point.y = y;
                point.down = true;
                if (id == 0) {
                    ImGui::GetIO().AddMousePosEvent(x, y);
                }
            }
            g_TouchCount = g_TouchPoints.size();
            break;
        }
        
        case AMOTION_EVENT_ACTION_UP:
        case AMOTION_EVENT_ACTION_POINTER_UP: {
            int id = AMotionEvent_getPointerId(inputEvent, pointerIndex);
            if (id == 0) {
                auto& io = ImGui::GetIO();
                io.AddMouseButtonEvent(0, false);
                for (const auto& [tid, pt] : g_TouchPoints) {
                    if (tid != 0 && pt.down) {
                        io.AddMousePosEvent(pt.x, pt.y);
                        g_TouchPoints[0] = pt;
                        g_TouchPoints.erase(tid);
                        break;
                    }
                }
                g_TouchPoints.erase(0);
            } else {
                g_TouchPoints.erase(id);
            }
            g_TouchCount = g_TouchPoints.size();
            break;
        }
        
        case AMOTION_EVENT_ACTION_CANCEL:
            g_TouchPoints.clear();
            g_TouchCount = 0;
            ImGui::GetIO().AddMouseButtonEvent(0, false);
            break;
    }
}

static int (*old_getWidth)(ANativeWindow* window);
static int hook_getWidth(ANativeWindow* window) {
    g_Egl.screenWidth = old_getWidth(window);
    return g_Egl.screenWidth;
}

static int (*old_getHeight)(ANativeWindow* window);
static int hook_getHeight(ANativeWindow* window) {
    g_Egl.screenHeight = old_getHeight(window);
    return g_Egl.screenHeight;
}